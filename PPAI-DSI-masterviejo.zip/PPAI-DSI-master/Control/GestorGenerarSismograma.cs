﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PPAI_DSI.Control
{
    public class GestorGenerarSismograma
    {
        // Constructor, atributos, etc. si fueran necesarios
        public GestorGenerarSismograma()
        {
            // Inicialización si es necesaria
        }

        // Método público para ejecutar el CU incluido
        public void ejecutar()
        {
            // Aquí no implementamos nada, sólo simulamos la llamada
            // En la implementación real generaría y mostraría el sismograma automáticamente
        }
    }
}

