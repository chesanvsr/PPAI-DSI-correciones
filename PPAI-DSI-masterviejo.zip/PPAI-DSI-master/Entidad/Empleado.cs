﻿using PPAI_DSI.Entidad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PPAI_DSI.Entidad
{
    public class Empleado
    {
        // Atributos
        private string nombre;
        private string apellido;

        // Constructor
        public Empleado(string nombre, string apellido) 
        {
            this.nombre = nombre;
            this.apellido = apellido;
        }

        // Métodos
    }
}